# --------------------------------------------------------------------------
# ------------  Metody Systemowe i Decyzyjne w Informatyce  ----------------
# --------------------------------------------------------------------------
#  Zadanie 4: Zadanie zaliczeniowe
#  autorzy: A. Gonczarek, J. Kaczmar, S. Zareba
#  2017
# --------------------------------------------------------------------------

import pickle
import numpy as np
from net import *


def predict(x):
    """
       Funkcja pobiera macierz przykladow zapisanych w macierzy X o wymiarach NxD i zwraca wektor y o wymiarach Nx1,
       gdzie kazdy element jest z zakresu {0, ..., 35} i oznacza znak rozpoznany na danym przykladzie.
       :param x: macierz o wymiarach NxD
       :return: wektor o wymiarach Nx1
       """

    nn = pickle.load(open('model_10-06.pkl', mode='rb'))
    return nn.predict(x).reshape((-1, 1))
